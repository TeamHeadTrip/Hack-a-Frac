Thanks for downloading my 3D floating islands, I created these for a game I made for my friends. I hope you enjoy using them, and it's saved you some time creating your own. 

Feel free to use them for any type of project. If they're useful to you, send me a tweet of thanks to @ongoingworlds - it might make my day! 

David Ball
www.ongoingworlds.com